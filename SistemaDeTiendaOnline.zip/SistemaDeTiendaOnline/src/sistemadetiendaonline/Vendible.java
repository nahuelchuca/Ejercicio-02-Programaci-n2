package sistemadetiendaonline;

public interface Vendible {
    double calcularPrecioFinal();
}

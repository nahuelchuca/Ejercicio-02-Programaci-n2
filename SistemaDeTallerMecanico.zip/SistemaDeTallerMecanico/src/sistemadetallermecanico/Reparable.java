package sistemadetallermecanico;

public interface Reparable {
    void reparar();
}

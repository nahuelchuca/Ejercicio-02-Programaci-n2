package sistemadecursos;

public class Persona {
    protected String nombre;
    protected String apellido;
    protected String DNI;
    
    public Persona(String nombre, String apellido, String DNI) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.DNI = DNI;
    }
    
}
